Fixes #

## Proposed Changes

---

## Checklist

- [ ] A test has been added if appropriate
- [ ] `npm test` completes successfully
- [ ] Commit messages are in [semantic format](https://seesparkbox.com/foundry/semantic_commit_messages)
