## Expected Behavior

## Actual Behavior

## Steps/Code to Reproduce the Problem

1. 1. 1.

```
const influx = require('influx')

// ...
```

## Specifications

- Version:
- Platform:
- Subsystem:
